﻿/*
 * This class consist the Business layer logics of a customer
 * Author : Tejas M
 * Date : 1/3/2024
*/

using Anual_Information_Return.Model;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLCustomer
    {
        #region Declarations
        SqlServerDb db = new SqlServerDb();
        string sqlQuery = string.Empty;
        #endregion

        #region Business public methods
        public List<BOCustomer> GetAllCustomerDetails()
        {
            List<BOCustomer> lstOfCustomers = new List<BOCustomer>();
            sqlQuery = "SELECT * FROM Customer";

            DataTable tblCustomerDetails = db.GetDataTable(sqlQuery);

            foreach (DataRow row in tblCustomerDetails.Rows)
            {
                BOCustomer customer = GetDetails(row);
                lstOfCustomers.Add(customer);
            }
            return lstOfCustomers;
        }

        public BOCustomer GetOnlyOneCustomerDetail(int id)
        {
            sqlQuery = $"SELECT * FROM Customer WHERE id = {id}";
            DataTable tblCustomerDetails = db.GetDataTable(sqlQuery);
            if (tblCustomerDetails.Rows.Count > 0)
            {
                DataRow row = tblCustomerDetails.Rows[0];
                return GetDetails(row);
            }
            return null;
        }

        public BOCustomer PostCustomerDetails(BOCustomer obj)
        {
            #region Validating Customer Details
            //Date of birth Validation
            if (obj.DOB >= DateTime.Today)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Date of Birth " + obj.DOB;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }
            //Gender Validation
            if (obj.Gender != 1 && obj.Gender != 2 && obj.Gender != 3)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Gender";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }
            BOCustomer bo = TalukAndDistrictValidation(obj);
            if (bo.IsSucces == false)
            {
                return bo;
            }
            //Pan number Validation
            string strRegex = @"[A-Z]{5}[0-9]{4}[A-Z]{1}$";
            Regex re = new Regex(strRegex);
            if (!re.IsMatch(obj.PanNumber))
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Pan number";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }
            #endregion

            string formattedDOB = obj.DOB.ToString("yyyy-MM-dd");

            sqlQuery = $"INSERT INTO CUSTOMER VALUES('{obj.FirstName}', '{obj.MiddleName}', '{obj.LastName}', '{obj.FatherName}', '{obj.MotherName}', '{formattedDOB}', {obj.Gender}, " +
                        $"'{obj.TempAdress.Area}', '{obj.TempAdress.Street}', '{obj.TempAdress.Pincode}', {obj.TempAdress.TalukID}, {obj.TempAdress.DistrictID}, " +
                        $"'{obj.PeramanentAdress.Area}', '{obj.PeramanentAdress.Street}', '{obj.PeramanentAdress.Pincode}', {obj.PeramanentAdress.TalukID}, {obj.PeramanentAdress.DistrictID}, " +
                        $"'{obj.MobileNumber}', '{obj.AadharNumber}', '{obj.PanNumber}', '{obj.EmailID}')";

            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                obj.IsSucces = true;
                obj.Message = "Saved successfully";
                obj.StatusCode = 200;
            }
            return obj;
        }

        public BOCustomer BLUpdateCustomerDetails(BOCustomer customer, int customerId)
        {
            #region Validating Customer Details
            //Date of birth Validation
            if (customer.DOB >= DateTime.Today)
            {
                customer.Message = "Invalid Date of Birth " + customer.DOB;
                customer.StatusCode = StatusCodes.Status202Accepted;
                return customer;
            }
            //Gender Validation
            if (customer.Gender != 1 && customer.Gender != 2 && customer.Gender != 3)
            {
                customer.Message = "Invalid Gender";
                customer.StatusCode = StatusCodes.Status202Accepted;
                return customer;
            }

            BOCustomer bo = TalukAndDistrictValidation(customer);
            if (bo.IsSucces == false)
            {
                return bo;
            }
            //Pan number Validation
            string strRegex = @"[A-Z]{5}[0-9]{4}[A-Z]{1}$";
            Regex re = new Regex(strRegex);
            if (!re.IsMatch(customer.PanNumber))
            {
                customer.Message = "Invalid Pan number";
                customer.StatusCode = StatusCodes.Status202Accepted;
                return customer;
            }
            #endregion

            string sqlQuery = $@"UPDATE Customer 
                        SET FirstName = '{customer.FirstName}',
                            MiddleName = '{customer.MiddleName}',
                            LastName = '{customer.LastName}',
                            FatherName = '{customer.FatherName}',
                            MotherName = '{customer.MotherName}',
                            DOB = '{customer.DOB.ToString("yyyy-MM-dd")}',
                            Gender = {customer.Gender},
                            TempArea = '{customer.TempAdress.Area}',
                            TempStreet = '{customer.TempAdress.Street}',
                            TempPincode = '{customer.TempAdress.Pincode}',
                            TempTalukID = {customer.TempAdress.TalukID},
                            TempDistrictID = {customer.TempAdress.DistrictID},
                            Parea = '{customer.PeramanentAdress.Area}',
                            PStreet = '{customer.PeramanentAdress.Street}',
                            PPincode = '{customer.PeramanentAdress.Pincode}',
                            PTalukID = {customer.PeramanentAdress.TalukID},
                            PDistrictID = {customer.PeramanentAdress.DistrictID},
                            MobileNumber = '{customer.MobileNumber}',
                            AadharNumber = '{customer.AadharNumber}',
                            PanNumber = '{customer.PanNumber}',
                            EmailID = '{customer.EmailID}'
                            WHERE id = {customerId}";

            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                customer.Message = "Saved successfully";
                customer.StatusCode = 200;
            }
            return customer;
        }

        public BOCustomer DeleteCustomerDetail(int id, BOCustomer customer)
        {
            BOCustomer bOCustomer = GetOnlyOneCustomerDetail(id);
            if (bOCustomer == null)
            {
                customer.Message = "The provided id is invalid";
                customer.StatusCode = StatusCodes.Status202Accepted;
                return customer;
            }

            sqlQuery = $"DELETE FROM CUSTOMER WHERE ID = {id}";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                customer.Message = "Deleted successfully";
                customer.StatusCode = StatusCodes.Status202Accepted;
            }
            return customer;
        }
        #endregion

        #region Helper methods
        private BOCustomer GetDetails(DataRow row)
        {
            BOCustomer customerObj = new BOCustomer
            {
                ID = Convert.ToInt32(row["id"]),
                FirstName = Convert.ToString(row["FirstName"]),
                MiddleName = Convert.ToString(row["MiddleName"]),
                LastName = Convert.ToString(row["LastName"]),
                FatherName = Convert.ToString(row["FatherName"]),
                MotherName = Convert.ToString(row["MotherName"]),
                DOB = Convert.ToDateTime(row["DOB"]),
                TempAdress = new Address
                {
                    Area = Convert.ToString(row["TempArea"]),
                    Street = Convert.ToString(row["TempStreet"]),
                    Pincode = Convert.ToString(row["TempPincode"]),
                    TalukID = Convert.ToInt32(row["TempTalukID"]),
                    DistrictID = Convert.ToInt32(row["TempDistrictID"])
                },
                PeramanentAdress = new Address
                {
                    Area = Convert.ToString(row["PArea"]),
                    Street = Convert.ToString(row["PStreet"]),
                    Pincode = Convert.ToString(row["PPincode"]),
                    TalukID = Convert.ToInt32(row["PTalukID"]),
                    DistrictID = Convert.ToInt32(row["PDistrictID"])
                },
                MobileNumber = Convert.ToString(row["MobileNumber"]),
                AadharNumber = Convert.ToString(row["AadharNumber"]),
                PanNumber = Convert.ToString(row["PanNumber"]),
                EmailID = Convert.ToString(row["EmailID"]),
                Gender = Convert.ToInt32(row["Gender"])
            };
            return customerObj;
        }
        #endregion

        #region Common Validation Methods
        private BOCustomer TalukAndDistrictValidation(BOCustomer bOCustomer)
        {
            BOTalukMaster permanentTaluk = new BLTalukMaster().GetTalukDetails(bOCustomer.PeramanentAdress.TalukID);
            BOTalukMaster temporaryTaluk = new BLTalukMaster().GetTalukDetails(bOCustomer.TempAdress.TalukID);

            if (permanentTaluk == null)
            {
                bOCustomer.IsSucces = false;
                bOCustomer.Message = "Invalid Peramanent Taluk Id";
                bOCustomer.StatusCode = StatusCodes.Status202Accepted;
                return bOCustomer;
            }
            if (temporaryTaluk == null)
            {
                bOCustomer.IsSucces = false;
                bOCustomer.Message = "Invalid temperory Taluk Id";
                bOCustomer.StatusCode = StatusCodes.Status202Accepted;
                return bOCustomer;
            }
            if (bOCustomer.PeramanentAdress.DistrictID != permanentTaluk.DistricID)
            {
                bOCustomer.IsSucces = false;
                bOCustomer.Message = "The Peramanant taluk doesent belong to this District";
                bOCustomer.StatusCode = StatusCodes.Status202Accepted;
                return bOCustomer;
            }
            if (bOCustomer.TempAdress.DistrictID != temporaryTaluk.DistricID)
            {
                bOCustomer.IsSucces = false;
                bOCustomer.Message = "The Temprory taluk doesent belong to this District";
                bOCustomer.StatusCode = StatusCodes.Status202Accepted;
                return bOCustomer;
            }

            return bOCustomer;
        }
        #endregion
    }
}
