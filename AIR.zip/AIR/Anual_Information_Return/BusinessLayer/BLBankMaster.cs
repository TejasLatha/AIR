﻿using Anual_Information_Return.Model;
using System.Collections.Generic;
using System.Data;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLBankMaster
    {
        #region Declaration
        string sqlQuery = string.Empty;
        SqlServerDb db = new SqlServerDb();
        #endregion

        #region Business public methods
        /// <summary>
        /// This method returns all the bank master details.
        /// </summary>
        /// <returns></returns>
        public List<BOBankMaster> GetAllBankDetails()
        {
            List<BOBankMaster> lstBankMaster = new List<BOBankMaster>();
            sqlQuery = "SELECT * FROM BankMaster";

            DataTable tblBankMaster = db.GetDataTable(sqlQuery);

            foreach (DataRow row in tblBankMaster.Rows)
            {
                BOBankMaster boBank = new BOBankMaster
                {
                    BankId = (int)row["BankId"],
                    BankName = (string)row["BankName"],
                    address = new Address
                    {
                        Area = (string)row["Area"],
                        Street = (string)row["Street"],
                        Pincode = (string)row["Pincode"],
                        TalukID = (int)row["TalukID"],
                        DistrictID = (int)row["DistrictID"]
                    }
                };

                lstBankMaster.Add(boBank);
            }
            return lstBankMaster;
        }

        /// <summary>
        /// This method returns bank master by getting Id as a parameter.
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public BOBankMaster GetOneBankDetail(int Id)
        {
            sqlQuery = "SELECT * FROM BankMaster WHERE BankId=" + Id + "";
            DataTable tblBankMaster = db.GetDataTable(sqlQuery);
            if (tblBankMaster.Rows.Count > 0)
            {
                DataRow row = tblBankMaster.Rows[0];
                return new BOBankMaster
                {
                    BankId = (int)row["BankId"],
                    BankName = (string)row["BankName"],
                    address = new Address
                    {
                        Area = (string)row["Area"],
                        Street = (string)row["Street"],
                        Pincode = (string)row["Pincode"],
                        TalukID = (int)row["TalukID"],
                        DistrictID = (int)row["DistrictID"]
                    }
                };
            }
            return null;
        }

        /// <summary>
        /// This method is used to save the bank master details.
        /// </summary>
        /// <param name="bankMaster"></param>
        /// <returns></returns>
        public BOBankMaster PostBankDetails(BOBankMaster bankMaster)
        {
            BOBankMaster bOBankMaster = TalukAndDistrictValidation(bankMaster);
            if (bOBankMaster.IsSucces == false)
            {
                return bOBankMaster;
            }

            sqlQuery = $"INSERT INTO BankMaster(BankName, Area, Street, Pincode, TalukID, DistrictID) VALUES('{bankMaster.BankName}', '{bankMaster.address.Area}', '{bankMaster.address.Street}', '{bankMaster.address.Pincode}', {bankMaster.address.TalukID}, {bankMaster.address.DistrictID})";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bankMaster.IsSucces = true;
                bankMaster.Message = "Saved successfully";
                bankMaster.StatusCode = 200;
            }
            return bankMaster;
        }

        /// <summary>
        /// This method is used to update the bank master details.
        /// </summary>
        /// <param name="bankMaster"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public BOBankMaster UpdateBankDetails(BOBankMaster bankMaster, int id)
        {
            BOBankMaster ob = GetOneBankDetail(id);
            if (ob == null)
            {
                bankMaster.Message = "Invalid Bank Id";
                bankMaster.StatusCode = StatusCodes.Status202Accepted;
                return bankMaster;
            }
            BOBankMaster bOBankMaster = TalukAndDistrictValidation(bankMaster);
            if (bOBankMaster.IsSucces == false)
            {
                return bOBankMaster;
            }
            sqlQuery = $"UPDATE BankMaster SET BankName='{bankMaster.BankName}', Area='{bankMaster.address.Area}', Street='{bankMaster.address.Street}', Pincode='{bankMaster.address.Pincode}', TalukID={bankMaster.address.TalukID}, DistrictID={bankMaster.address.DistrictID} WHERE BankId={id}";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bankMaster.Message = "Saved successfully";
                bankMaster.StatusCode = 200;
            }
            return bankMaster;
        }

        /// <summary>
        /// This method is used to delete the bank master details.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public BOBankMaster DeleteBankDetail(int id, BOBankMaster bOBankMaster)
        {
            BOBankMaster ob = GetOneBankDetail(id);
            if (ob == null)
            {
                bOBankMaster.Message = "Invalid Bank Id";
                bOBankMaster.StatusCode = StatusCodes.Status202Accepted;
                return bOBankMaster;
            }
            sqlQuery = $"DELETE FROM BankMaster WHERE BankId={id}";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bOBankMaster.Message = "Deleted successfully";
                bOBankMaster.StatusCode = 200;
            }
            return bOBankMaster;

            //Old Code

            /* sqlQuery = $"DELETE FROM BankMaster WHERE BankId={id}";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0;*/

        }
        #endregion

        #region Common validation methods
        private BOBankMaster TalukAndDistrictValidation(BOBankMaster bo)
        {
            BOTalukMaster boTaluk = new BLTalukMaster().GetTalukDetails(bo.address.TalukID);


            if (boTaluk == null)
            {
                bo.IsSucces = false;
                bo.Message = "Invalid Taluk Id";
                bo.StatusCode = StatusCodes.Status202Accepted;
                return bo;
            }

            if (bo.address.DistrictID != boTaluk.DistricID)
            {
                bo.IsSucces = false;
                bo.Message = "The taluk doesent belong to this District";
                bo.StatusCode = StatusCodes.Status202Accepted;
                return bo;
            }

            return bo;
        }
        #endregion
    }
}
