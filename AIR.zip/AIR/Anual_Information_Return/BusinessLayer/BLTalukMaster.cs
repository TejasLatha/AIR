﻿using Anual_Information_Return.Model;
using System.Data;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLTalukMaster
    {
        #region Object Declarations

        string sqlQuery = string.Empty;
        SqlServerDb db = new SqlServerDb();
        BOTalukMaster bo_Object = new BOTalukMaster();

        #endregion

        public List<BOTalukMaster> GetAllTalukMasterDetails()
        {
            List<BOTalukMaster> lstTalukMaster = new List<BOTalukMaster>();
            sqlQuery = "select * from TalukMaster";
            DataTable talukMasterDetails = db.GetDataTable(sqlQuery);
            lstTalukMaster = GetDetails(talukMasterDetails);
            return lstTalukMaster;
        }

        public BOTalukMaster GetTalukDetails(int id)
        {
            BOTalukMaster bOTalukMaster = new BOTalukMaster();
            sqlQuery = "select * from TalukMaster where Id=" + id + "";
            DataTable tblDistrictMaster = db.GetDataTable(sqlQuery);
            bOTalukMaster = GetDetails(tblDistrictMaster).FirstOrDefault();
            return bOTalukMaster;
        }

        private List<BOTalukMaster> GetDetails(DataTable talukMasterDetails)
        {
            List<BOTalukMaster> lstTalukMaster = new List<BOTalukMaster>();
            for (int i = 0; i < talukMasterDetails.Rows.Count; i++)
            {
                BOTalukMaster newBOObject = new BOTalukMaster();
                newBOObject.Id = (int)talukMasterDetails.Rows[i]["Id"];
                newBOObject.Name = (string)talukMasterDetails.Rows[i]["Name"];
                newBOObject.DistricID = (int)talukMasterDetails.Rows[i]["DistrictID"];
                newBOObject.IsSucces = true;
                newBOObject.Message = "Fetched Succesfully";
                newBOObject.StatusCode = StatusCodes.Status200OK;
                lstTalukMaster.Add(newBOObject);
            }
            return lstTalukMaster;
        }

        public BOTalukMaster BLPostDetails(BOTalukMaster bOTalukMaster)
        {
            bOTalukMaster = DistrictValidation(bOTalukMaster);
            if (bOTalukMaster.IsSucces == false)
            {
                return bOTalukMaster;
            }

            sqlQuery = "INSERT INTO TALUKMASTER VALUES('" + bOTalukMaster.Name + "'," + bOTalukMaster.DistricID + ")";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bOTalukMaster.IsSucces = true;
                bOTalukMaster.Message = "Saved successfully";
                bOTalukMaster.StatusCode = 200;
            }
            return bOTalukMaster;
        }

        public BOTalukMaster PutTalukDetails(int id, BOTalukMaster bOTalukMaster)
        {
            BOTalukMaster bo1 = DistrictValidation(bOTalukMaster);

            if (bo1.IsSucces == false)
            { return bo1; }

            BOTalukMaster talukMasterObj = new BLTalukMaster().GetTalukDetails(bOTalukMaster.Id);
            if (talukMasterObj == null || talukMasterObj.DistricID != talukMasterObj.DistricID)
            {
                bOTalukMaster.IsSucces = false;
                bOTalukMaster.Message = "Invalid Taluk Id";
                bOTalukMaster.StatusCode = StatusCodes.Status202Accepted;
                return bOTalukMaster;
            }

            sqlQuery = "UPDATE TalukMaster SET NAME='" + bOTalukMaster.Name + "',DISTRICTID= " + bOTalukMaster.DistricID + " WHERE ID = " + id + "";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bOTalukMaster.IsSucces = true;
                bOTalukMaster.Message = "Saved successfully";
                bOTalukMaster.StatusCode = 200;
            }
            return bOTalukMaster;
        }

        public bool DeleteTalukDetail(int id)
        {
            sqlQuery = " DELETE FROM TalukMaster WHERE ID = " + id + "";
            int result = db.ExecuteOnlyQuery(sqlQuery);
            return result == 0 ? false : true;
        }

        private BOTalukMaster DistrictValidation(BOTalukMaster bOTalukMaster)
        {
            BODistrictMaster districtMaster = new BLDistrictMaster().GetDistrictMaster(bOTalukMaster.DistricID);
            if (districtMaster == null)
            {
                bOTalukMaster.IsSucces = false;
                bOTalukMaster.Message = "Invalid District Id";
                bOTalukMaster.StatusCode = StatusCodes.Status404NotFound;
            }
            return bOTalukMaster;
        }
    }
}
