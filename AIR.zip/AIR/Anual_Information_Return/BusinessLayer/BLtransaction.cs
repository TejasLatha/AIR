﻿using Anual_Information_Return.Model;
using System.Data;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLtransaction
    {
        #region Declarations
        string sqlQuery = string.Empty;
        SqlServerDb db = new SqlServerDb();
        #endregion

        #region Business public methods

        public List<BOtransaction> GetAllTransactionDetails()
        {
            List<BOtransaction> lstOfbOtransactions = new List<BOtransaction>();
            sqlQuery = "SELECT * FROM BOtransaction";

            DataTable tblTransactionsDetails = db.GetDataTable(sqlQuery);

            foreach (DataRow row in tblTransactionsDetails.Rows)
            {
                BOtransaction transaction = GetDetails(row);
                lstOfbOtransactions.Add(transaction);
            }
            return lstOfbOtransactions;
        }

        public BOtransaction GetOnlyOneTransactionDetail(int id)
        {
            sqlQuery = $"SELECT * FROM BOtransaction WHERE id = {id}";
            DataTable tblTransactionsDetails = db.GetDataTable(sqlQuery);
            if (tblTransactionsDetails.Rows.Count > 0)
            {
                DataRow row = tblTransactionsDetails.Rows[0];
                return GetDetails(row);
            }
            return null;
        }

        private BOtransaction GetDetails(DataRow row)
        {
            BOtransaction obj = new BOtransaction()
            {
                Id = Convert.ToInt32(row["Id"]),
                CustomerId = Convert.ToInt32(row["CustomerId"]),
                BranchId = Convert.ToInt32(row["BranchId"]),
                Amount = Convert.ToDecimal(row["Amount"]),
                DateOfTransaction = Convert.ToDateTime(row["DateOfTransaction"]),
                DoneBy = Convert.ToString(row["DoneBy"]),
                CreatedDate = Convert.ToDateTime(row["DateOfTransaction"])
            };
            return obj;
        }

        public BOtransaction PostTransactionDetails(BOtransaction obj)
        {
            #region Validating the Transaction Details

            BOCustomer customer = new BLCustomer().GetOnlyOneCustomerDetail(obj.CustomerId);
            if (customer == null)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Customer Id" + obj.CustomerId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            BOBranch bOBranch = new BLBranch().GetOneBranchDetail(obj.BranchId);
            if (bOBranch == null)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Branch Id" + obj.BranchId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.Amount >= 1000000)
            {
                obj.IsSucces = false;
                obj.Message = "You entered more than 10 lack,So we can't accept it" + obj.CustomerId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            DateTime oldYear = new DateTime(2023, 3, 31); // Replace this with the desired starting date
            if (obj.DateOfTransaction < DateTime.Today && obj.DateOfTransaction > oldYear)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid Date of Transaction. Date must be today or a date in the past, and must be Greater than " + oldYear.ToString("yyyy-MM-dd") + ".";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.DoneBy == null)
            {
                obj.IsSucces = false;
                obj.Message = "The 'Done By' field must be filled in. Please provide the person who completed the transaction.";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.CreatedDate < obj.DateOfTransaction || obj.CreatedDate > DateTime.Now)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid creating date. Tha created date must be greater than or equal to The Date of Transtation";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }
            #endregion

            sqlQuery = $"INSERT INTO BOtransaction (CustomerId, BranchId, Amount, DateOfTransaction, DoneBy, CreatedDate) " +
                  $"VALUES ({obj.CustomerId}, {obj.BranchId}, {obj.Amount}, '{obj.DateOfTransaction:yyyy-MM-dd}', " +
                  $"'{obj.DoneBy}', '{obj.CreatedDate:yyyy-MM-dd}')";

            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                obj.IsSucces = true;
                obj.Message = "Saved successfully";
                obj.StatusCode = 200;
            }
            return obj;
        }

        public BOtransaction UpdateTransactionDetails(BOtransaction obj, int id)
        {
            #region Validating the Transaction Details

            BOCustomer customer = new BLCustomer().GetOnlyOneCustomerDetail(obj.CustomerId);
            if (customer == null)
            {
                obj.Message = "Invalid Customer Id " + obj.CustomerId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            BOBranch bOBranch = new BLBranch().GetOneBranchDetail(obj.BranchId);
            if (bOBranch == null)
            {
                obj.Message = "Invalid Branch Id" + obj.BranchId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.Amount >= 1000000)
            {
                obj.Message = "You entered more than 10 lack,So we can't accept it" + obj.CustomerId;
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            DateTime oldYear = new DateTime(2023, 3, 31); // Replace this with the desired starting date
            if (obj.DateOfTransaction < DateTime.Today && obj.DateOfTransaction > oldYear)
            {
                obj.Message = "Invalid Date of Transaction. Date must be today or a date in the past, and must be Greater than " + oldYear.ToString("yyyy-MM-dd") + ".";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.DoneBy == null)
            {
                obj.IsSucces = false;
                obj.Message = "The 'Done By' field must be filled in. Please provide the person who completed the transaction.";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }

            if (obj.CreatedDate < obj.DateOfTransaction || obj.CreatedDate > DateTime.Now)
            {
                obj.IsSucces = false;
                obj.Message = "Invalid creating date. Tha created date must be greater than or equal to The Date of Transtation";
                obj.StatusCode = StatusCodes.Status202Accepted;
                return obj;
            }
            #endregion

            sqlQuery = $"UPDATE BOtransaction SET " +
                  $"CustomerId = {obj.CustomerId}, " +
                  $"BranchId = {obj.BranchId}, " +
                  $"Amount = {obj.Amount}, " +
                  $"DateOfTransaction = '{obj.DateOfTransaction.ToString("yyyy-MM-dd")}', " +
                  $"DoneBy = '{obj.DoneBy}', " +
                  $"CreatedDate = '{obj.CreatedDate.ToString("yyyy-MM-dd")}' " +
                  $"WHERE Id = {obj.Id}";

            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                obj.Message = "Updated successfully";
                obj.StatusCode = StatusCodes.Status202Accepted;
            }
            return obj;
        }

        public BOtransaction DeleteTransactionDetails(int id, BOtransaction bo)
        {
            BOtransaction result = GetOnlyOneTransactionDetail(id);
            if (result == null)
            {
                bo.Message = "Invalid Transaction ID";
                bo.StatusCode = StatusCodes.Status202Accepted;
                return bo;
            }

            sqlQuery = "DELETE FROM BOtransaction WHERE ID = " + id + "";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                bo.Message = "Deleted successfully";
                bo.StatusCode = StatusCodes.Status202Accepted;
            }

            return bo;
        }
        #endregion
    }
}
