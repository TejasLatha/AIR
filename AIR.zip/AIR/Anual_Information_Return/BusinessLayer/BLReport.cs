﻿using Anual_Information_Return.Model;
using System.Data;
using static Anual_Information_Return.Model.BOReport.BOReport;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLReport
    {
        string sqlQuery = string.Empty;
        SqlServerDb db = new SqlServerDb();
        public List<BranchReport>  GetBranchDetailsByTalukName(string TalukName)
        {
            List<BranchReport> branches = new List<BranchReport>();
            sqlQuery = "SELECT\r\n\tb.BRANCHNAME \r\n   ,b.CODE \r\n   ,b.IFSCCODE \r\n   ,b.AREA \r\n   ,b.STREET\r\n   ,b.PINCODE \r\n   ,tm.NAME \r\n   ,dm.DistrictName\r\nFROM BRANCHMASTER b\r\nINNER JOIN TalukMaster tm ON b.TALUKID=tm.ID\r\nINNER JOIN DistrictMaster dm ON b.DISTRICTID=dm.DistrictId\r\nWHERE tm.NAME LIKE '"+ TalukName + "'";            DataTable branchReportDetails = db.GetDataTable(sqlQuery);
            
            foreach (DataRow row in branchReportDetails.Rows)
            {
                BranchReport ob = new BranchReport();
                ob.Branchname = row["BRANCHNAME"].ToString();
                ob.BranchCode = row["CODE"].ToString();
                ob.IfscCode = row["IfscCode"].ToString();
                ob.Area = row["AREA"].ToString();
                ob.Street = row["STREET"].ToString();
                ob.Pincode = row["PINCODE"].ToString();
               
                branches.Add(ob);
            }
            return branches;
        }

        public List<BranchReport> GetBranchDetailsByDistrictId(int DistrictId)
        {
            List<BranchReport> branches = new List<BranchReport>();
            sqlQuery = "SELECT\r\n\tb.BRANCHNAME \r\n   ,b.CODE \r\n   ,b.IFSCCODE \r\n   ,b.AREA \r\n   ,b.STREET\r\n   ,b.PINCODE \r\n   ,tm.NAME \r\n   ,dm.DistrictName\r\nFROM BRANCHMASTER b\r\nINNER JOIN TalukMaster tm ON b.TALUKID=tm.ID\r\nINNER JOIN DistrictMaster dm ON b.DISTRICTID=dm.DistrictId\r\nWHERE b.DISTRICTID = " + DistrictId + "";
            DataTable branchReportDetails = db.GetDataTable(sqlQuery);

            foreach (DataRow row in branchReportDetails.Rows)
            {
                BranchReport ob = new BranchReport();
                ob.Branchname = row["BRANCHNAME"].ToString();
                ob.BranchCode = row["CODE"].ToString();
                ob.IfscCode = row["IfscCode"].ToString();
                ob.Area = row["AREA"].ToString();
                ob.Street = row["STREET"].ToString();
                ob.Pincode = row["PINCODE"].ToString();

                branches.Add(ob);
            }
            return branches;
        }

        public List<BranchReport> GetBranchDetailsByTalukId(int TalukId)
        {
            List<BranchReport> branches = new List<BranchReport>();
            sqlQuery = "SELECT\r\n\tb.BRANCHNAME \r\n   ,b.CODE \r\n   ,b.IFSCCODE \r\n   ,b.AREA \r\n   ,b.STREET\r\n   ,b.PINCODE \r\n   ,tm.NAME \r\n   ,dm.DistrictName\r\nFROM BRANCHMASTER b\r\nINNER JOIN TalukMaster tm ON b.TALUKID=tm.ID\r\nINNER JOIN DistrictMaster dm ON b.DISTRICTID=dm.DistrictId\r\nWHERE b.DISTRICTID = " + TalukId + "";
            DataTable branchReportDetails = db.GetDataTable(sqlQuery);

            foreach (DataRow row in branchReportDetails.Rows)
            {
                BranchReport ob = new BranchReport();
                ob.Branchname = row["BRANCHNAME"].ToString();
                ob.BranchCode = row["CODE"].ToString();
                ob.IfscCode = row["IfscCode"].ToString();
                ob.Area = row["AREA"].ToString();
                ob.Street = row["STREET"].ToString();
                ob.Pincode = row["PINCODE"].ToString();

                branches.Add(ob);
            }
            return branches;
        }
    }
}
