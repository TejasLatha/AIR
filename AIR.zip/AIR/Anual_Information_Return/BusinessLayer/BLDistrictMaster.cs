﻿using Anual_Information_Return.Model;
using System.Data;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLDistrictMaster
    {
        #region Declarations

        string sqlQuery = string.Empty;
        SqlServerDb db = new SqlServerDb();
        BODistrictMaster boDM = new BODistrictMaster();

        #endregion

        #region Business public methods

        /// <summary>
        /// This method returns all the district master details.
        /// </summary>
        /// <returns>A list of district master details.</returns>
        public List<BODistrictMaster> GetAllDistrictDetails()
        {
            List<BODistrictMaster> lstDistrictMaster = new List<BODistrictMaster>();
            sqlQuery = "select * from DistrictMaster";

            DataTable tblDistrictMaster = db.GetDataTable(sqlQuery);

            for (int i = 0; i < tblDistrictMaster.Rows.Count; i++)
            {
                BODistrictMaster bODistrict = new BODistrictMaster();
                bODistrict.Id = (int)tblDistrictMaster.Rows[i]["DistrictId"];
                bODistrict.DistrictName = (string)tblDistrictMaster.Rows[i]["DistrictName"];
                lstDistrictMaster.Add(bODistrict);
            }
            return lstDistrictMaster;
        }

        /// <summary>
        /// This method returns district master by getting Id as a parameter.
        /// </summary>
        /// <param name="Id">The ID of the district.</param>
        /// <returns>The district master details.</returns>
        public BODistrictMaster GetDistrictMaster(int Id)
        {
            sqlQuery = "select * from DistrictMaster where DistrictId=" + Id + "";
            DataTable tblDistrictMaster = db.GetDataTable(sqlQuery);
            if (tblDistrictMaster.Rows.Count > 0)
            {
                boDM = new BODistrictMaster();
                boDM.Id = (int)tblDistrictMaster.Rows[0]["DistrictId"];
                boDM.DistrictName = (string)tblDistrictMaster.Rows[0]["DistrictName"];
                return boDM;
            }
            return null;
        }

        /// <summary>
        /// This method is used to save the District master details.
        /// </summary>
        /// <param name="bodm">The district master object to be saved.</param>
        /// <returns>True if the save operation is successful; otherwise, false.</returns>
        public bool SaveDistrictMasterDetails(BODistrictMaster bodm)
        {
            sqlQuery = "INSERT INTO DISTRICTMASTER(DISTRICTNAME) VALUES('" + bodm.DistrictName + "')";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0 ? true : false;
        }

        /// <summary>
        /// This method is used to update the district master details.
        /// </summary>
        /// <param name="bODistrictMaster">The district master object with updated details.</param>
        /// <returns>True if the update operation is successful; otherwise, false.</returns>
        public bool UpdateDistrictMasterDetails(BODistrictMaster bODistrictMaster)
        {
            sqlQuery = "UPDATE DistrictMaster SET DISTRICTNAME='" + bODistrictMaster.DistrictName + "' WHERE DistrictId=" + bODistrictMaster.Id + "";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0 ? true : false;
        }

        /// <summary>
        /// This method is used to delete the District master details.
        /// </summary>
        /// <param name="id">The ID of the district to be deleted.</param>
        /// <returns>True if the delete operation is successful; otherwise, false.</returns>
        public bool DeleteDistrictMasterDetail(int id)
        {
            sqlQuery = "delete from DistrictMaster where DistrictId=" + id + "";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0 ? true : false;
        }

        #endregion
    }
}
