﻿using Anual_Information_Return.Model;
using System.Data;

namespace Anual_Information_Return.BusinessLayer
{
    public class BLBranch
    {
        #region Declarations
        private readonly SqlServerDb db = new SqlServerDb();
        string sqlQuery = string.Empty;
        #endregion
         
        #region Business public methods
        public List<BOBranch> GetAllBranchDetails()
        {
            var lstBranchMaster = new List<BOBranch>();
            sqlQuery = "SELECT * FROM BranchMaster";
            var tblBranchMaster = db.GetDataTable(sqlQuery);

            foreach (DataRow row in tblBranchMaster.Rows)
            {
                var boBranch = GetBranchFromDataRow(row);
                lstBranchMaster.Add(boBranch);
            }
            return lstBranchMaster;
        }

        public BOBranch GetOneBranchDetail(int id)
        {
            sqlQuery = "SELECT * FROM BranchMaster WHERE BranchId=" + id + "";
            var tblBranchMaster = db.GetDataTable(sqlQuery);
            if (tblBranchMaster.Rows.Count > 0)
            {
                var row = tblBranchMaster.Rows[0];
                return GetBranchFromDataRow(row);
            }
            return null;
        }

        public BOBranch PostBranchDetails(BOBranch branchMaster)
        {
            // Bank id validation
            BOBankMaster bankMaster = new BLBankMaster().GetOneBankDetail(branchMaster.BankId);
            if (bankMaster == null)
            {
                branchMaster.IsSucces = false;
                branchMaster.Message = "Invalid Bank id";
                return branchMaster;
            }

            // Taluk validation
            BOBranch boObj = TalukAndDistrictValidation(branchMaster);
            if (boObj.IsSucces == false)
            {
                return boObj;
            }

            sqlQuery = "INSERT INTO BranchMaster VALUES('" + branchMaster.BranchName + "','" + branchMaster.Code + "','" + branchMaster.IfscCode + "','" + branchMaster.Address.Area + "', '" + branchMaster.Address.Street + "', '" + branchMaster.Address.Pincode + "', " + branchMaster.Address.TalukID + "," + branchMaster.Address.DistrictID + "," + branchMaster.BankId + ")";
            int count = db.ExecuteOnlyQuery(sqlQuery);
            if (count > 0)
            {
                branchMaster.IsSucces = true;
                branchMaster.Message = "Saved successfully";
                branchMaster.StatusCode = 200;
            }
            return branchMaster;
        }

        public bool UpdateBranchDetails(BOBranch branchMaster, int id)
        {
            sqlQuery = $"UPDATE BranchMaster SET BranchName='{branchMaster.BranchName}', " +
                       $"Area='{branchMaster.Address.Area}', Street='{branchMaster.Address.Street}', " +
                       $"Pincode='{branchMaster.Address.Pincode}', TalukID={branchMaster.Address.TalukID}, " +
                       $"DistrictID={branchMaster.Address.DistrictID}, Bankid ={branchMaster.BankId} WHERE BranchId={id}";
            var count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0;
        }

        public bool DeleteBranchDetail(int id)
        {
            sqlQuery = $"DELETE FROM BranchMaster WHERE BranchId={id}";
            var count = db.ExecuteOnlyQuery(sqlQuery);
            return count > 0;
        }
        #endregion

        #region Helper methods
        private BOBranch GetBranchFromDataRow(DataRow row)
        {
            return new BOBranch
            {
                BranchId = (int)row["BranchId"],
                BranchName = (string)row["BranchName"],
                Address = new Address
                {
                    Area = (string)row["Area"],
                    Street = (string)row["Street"],
                    Pincode = (string)row["Pincode"],
                    TalukID = (int)row["TalukID"],
                    DistrictID = (int)row["DistrictID"]
                },
                BankId = (int)row["BankId"]
            };
        }
        #endregion

        #region Common validation methods
        private BOBranch TalukAndDistrictValidation(BOBranch bo)
        {
            BOTalukMaster boTaluk = new BLTalukMaster().GetTalukDetails(bo.Address.TalukID);
            if (boTaluk == null)
            {
                bo.IsSucces = false;
                bo.Message = "Invalid Taluk Id";
                bo.StatusCode = StatusCodes.Status202Accepted;
                return bo;
            }

            if (bo.Address.DistrictID != boTaluk.DistricID)
            {
                bo.IsSucces = false;
                bo.Message = "The taluk doesent belong to this District";
                bo.StatusCode = StatusCodes.Status202Accepted;
                return bo;
            }

            return bo;
        }
        #endregion
    }
}
