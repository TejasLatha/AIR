﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DistrictMasterController : ControllerBase
    {
        BLDistrictMaster bLDistrictMaster = new BLDistrictMaster();

        [HttpGet]
        [Route("AllDistricts")]
        public IActionResult GetAllDistrictsDetails()
        {
            List<BODistrictMaster> lstDistrictMaster = new List<BODistrictMaster>();
            lstDistrictMaster = bLDistrictMaster.GetAllDistrictDetails();

            return Ok(lstDistrictMaster);
        }

        [HttpGet]
        [Route("District")]
        public IActionResult GetDistrictsDetails([FromQuery] int Id)
        {
            BODistrictMaster bodm = bLDistrictMaster.GetDistrictMaster(Id);
            return bodm.Id==0 ? NotFound("District not found for the Id " + Id) :Ok(bodm);
        }

        [HttpPost]
        [Route("Save")]
        public IActionResult PostDistrictMasterDetails([FromBody] BODistrictMaster bodm)
        {
            bool saved = bLDistrictMaster.SaveDistrictMasterDetails(bodm);
            return saved ? Created("", "Created successfully") : StatusCode(500);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateDistrictMasterDetail([FromQuery] int id, [FromBody] BODistrictMaster bODistrictMaster)
        {
            bODistrictMaster.Id = id;
            bool saved = bLDistrictMaster.UpdateDistrictMasterDetails(bODistrictMaster);
            return saved ? Created("", "Updated successfully") : StatusCode(500);
            
        }

        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteDistrictMasterDetail([FromQuery] int id)
        {
            bool deleted = bLDistrictMaster.DeleteDistrictMasterDetail(id);
            return deleted ? Created("", "Deleted Successfully") : StatusCode(500);
        }
    }
}
