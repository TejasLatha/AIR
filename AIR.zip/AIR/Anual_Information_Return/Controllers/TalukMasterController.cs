﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TalukMasterController : ControllerBase
    {
        BLTalukMaster obj = new BLTalukMaster();
        // GET: api/<TalukMasterController>
        [HttpGet] 
        public IActionResult GetAllTalukMasterDetails()
        {
            List<BOTalukMaster> lstDistrictMaster = new List<BOTalukMaster>();
            lstDistrictMaster = obj.GetAllTalukMasterDetails();

            return Ok(lstDistrictMaster);
        }

        // GET api/<TalukMasterController>/5
        [HttpGet]
        [Route("GetOneTalukDetails")]
        public IActionResult GetTalukDetail([FromQuery] int id)
        {
            BOTalukMaster bodm = obj.GetTalukDetails(id);
            return bodm == null ? NotFound("Taluk not found for the Id "+id) : StatusCode(bodm.StatusCode, bodm);
        }

        // POST api/<TalukMasterController>
        [HttpPost]
        [Route("PostDetails")]
        public IActionResult PostTalukDetails([FromBody] BOTalukMaster bOTalukMaster)
        {
            BOTalukMaster saved = new BLTalukMaster().BLPostDetails(bOTalukMaster);
            return StatusCode(saved.StatusCode, saved);
        }

        // PUT api/<TalukMasterController>/5
        [HttpPut]
        [Route("PutDetails")]
        public IActionResult PutTalukDetails([FromQuery] int id, [FromBody] BOTalukMaster bOTalukMaster)
        {
            /*BLTalukMaster obj = new BLTalukMaster();
            if (obj.PutTalukDetails(id, bOTalukMaster))
            {
                return Created(" ", "Updated Succesfully");
            }
            return BadRequest();*/

            BOTalukMaster saved = new BLTalukMaster().PutTalukDetails(id, bOTalukMaster);
            return StatusCode(saved.StatusCode, saved);
        }

        // DELETE api/<TalukMasterController>/5
        [HttpDelete]
        [Route("DeleteTalukDetail")]
        public IActionResult Delete([FromQuery] int id)
        {
            BLTalukMaster obj = new BLTalukMaster();
            /*  if (obj.DeleteTalukDetail(id))
              {
                  return Created(" ", "Deleated Succesfully ");
              }
              return BadRequest();*/

            return obj.DeleteTalukDetail(id) ? Ok("Deleted Succesfully") : BadRequest();


        }
    }
}
