﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        BLtransaction BLtransactionobj = new BLtransaction();
        // GET: api/<TransactionController>
        [HttpGet]
        public IActionResult GetAllTransactionDetails()
        {
            List<BOtransaction> lstOfTransaction = new List<BOtransaction>();
            lstOfTransaction = BLtransactionobj.GetAllTransactionDetails();
            return lstOfTransaction?.Any() != true ? Ok("There is no data in a table"):Ok(lstOfTransaction);
        }
       
        // GET api/<TransactionController>/5
        [HttpGet]
        [Route("GetTransactionDetailsById")]
        public IActionResult GetTransactionDetail([FromQuery] int id)
        {
            BOtransaction bOtransaction = BLtransactionobj.GetOnlyOneTransactionDetail(id);
        /*    if(bOtransaction == null)
            {
                return BadRequest("Invalid Transaction ID");
            }
            return Ok(bOtransaction);*/

            return bOtransaction == null? NotFound("Invalid Transaction ID"): Ok(bOtransaction);
        }

        // POST api/<TransactionController>
        [HttpPost]
        [Route("PostTransactionDetail")]
        public IActionResult PostTransactionDetail([FromBody] BOtransaction bo)
        {
            BOtransaction saved = BLtransactionobj.PostTransactionDetails(bo);
            return StatusCode(saved.StatusCode, saved);
        }

        // PUT api/<TransactionController>/5
        [HttpPut]
        [Route("PutTransactionDetail")]
        public IActionResult PutTransactionDetail([FromQuery] int id, [FromBody] BOtransaction bo)
        {
            BOtransaction result = BLtransactionobj.UpdateTransactionDetails(bo, id);
            return StatusCode(result.StatusCode, result.Message);
            //return (BLtransactionobj.UpdateTransactionDetails(bo, id)) == true ? Ok("Updated successfully") : StatusCode(500);
        }

        // DELETE api/<TransactionController>/5
        [HttpDelete]
        [Route("DeleteTransactionDetilbyId")]
        public IActionResult DeleteTransactionDetil([FromQuery]int id, BOtransaction bo)
        {

            BOtransaction result = BLtransactionobj.DeleteTransactionDetails(id,bo);
            return StatusCode(result.StatusCode, result.Message);
            //return (BLtransactionobj.DeleteTransactionDetails(id)) == true ? Ok("Deleted successfully") : (StatusCode(500));
        }
    }
}
