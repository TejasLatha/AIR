﻿using Anual_Information_Return.BusinessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Anual_Information_Return.Model.BOReport.BOReport;

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    
    public class ReportController : ControllerBase
    {
        BLReport ob = new BLReport();
        [HttpGet]
        [Route("GetBranchReportByTalukName")]
        public IActionResult GetBranchReportbyTalukReference([FromQuery] string TalukName)
        {
            List<BranchReport> branches = new List<BranchReport>();
            branches = ob.GetBranchDetailsByTalukName(TalukName);
            return branches.Any() != true ? NotFound("There is no branch report available for this taluk.") :Ok(branches);
        }

        [HttpGet]
        [Route("GetBranchReportByDistrictId")]
        public IActionResult GetBranchReportbyDistrictIdReference([FromQuery]int districtId)
        {
            List<BranchReport> branches = new List<BranchReport>();
            branches = ob.GetBranchDetailsByDistrictId(districtId);
            return branches.Any() != true ? NotFound("There is no branch report available for this District ID.") : Ok(branches);
        }

        [HttpGet]
        [Route("GetBranchReportByTalukId")]
        public IActionResult GetBranchReportbyTalukIdReference([FromQuery] int TalukId)
        {
            List<BranchReport> branches = new List<BranchReport>();
            branches = ob.GetBranchDetailsByTalukId(TalukId);
            return branches.Any() != true ? NotFound("There is no branch report available for this Taluk ID.") : Ok(branches);
        }
    }
}
