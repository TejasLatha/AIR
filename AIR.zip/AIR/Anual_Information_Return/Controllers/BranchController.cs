﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {
        BLBranch branchObj = new BLBranch();

        // GET: api/<BranchController>
        [HttpGet]
        public IEnumerable<BOBranch> GetBranchDetails()
        {
            return branchObj.GetAllBranchDetails();
        }

        // GET api/<BranchController>/5
        [HttpGet("{id}")]
        public ActionResult<BOBranch> GetBranchDetailById(int id)
        {
            var branch = branchObj.GetOneBranchDetail(id);
            if (branch == null)
            {
                return NotFound();
            }
            return branch;
        }

        // POST api/<BranchController>
        [HttpPost]
        public IActionResult PostBranchDetails([FromBody] BOBranch branch)
        {
            BOBranch saved = branchObj.PostBranchDetails(branch);
            return StatusCode(saved.StatusCode, saved);
        }

        // PUT api/<BranchController>/5
        [HttpPut("{id}")]
        public IActionResult PutBranchDetail(int id, [FromBody] BOBranch branch)
        {
            if (branchObj.UpdateBranchDetails(branch, id))
            {
                return Ok("Updated successfully");
            }
            return StatusCode(500);
        }

        // DELETE api/<BranchController>/5
        [HttpDelete("{id}")]
        public IActionResult DeleteBranchDetail(int id)
        {
            /*if (branchObj.DeleteBranchDetail(id))
            {
                return Ok("Deleted successfully");
            }
            return StatusCode(500);*/

            return branchObj.DeleteBranchDetail(id) ? Ok("Deleted successfully") : StatusCode(500);
        }
    }
}
