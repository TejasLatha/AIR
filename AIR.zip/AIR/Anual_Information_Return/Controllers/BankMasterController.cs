﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankMasterController : ControllerBase
    {
        BLBankMaster BankMasterObj = new BLBankMaster();

        // GET: api/<BankMasterController>
        [HttpGet]
        [Route("GetAllBankDetails")]
        public IActionResult GetAllBankDetails()
        {
            List<BOBankMaster> lstOfBanks = new List<BOBankMaster>();
            lstOfBanks = BankMasterObj.GetAllBankDetails();
            return lstOfBanks?.Any() != true ? Ok("The Bank table is empty") : Ok(lstOfBanks);
        }

        // GET api/<BankMasterController>/5
        [HttpGet]
        [Route("GetOneBankDetail")]
        public IActionResult GetOneBankDetail([FromQuery] int id)
        {
            BOBankMaster obj = BankMasterObj.GetOneBankDetail(id);
            return obj == null ? NotFound("Invalid Bank ID") : Ok(obj);
        }

        // POST api/<BankMasterController>
        [HttpPost]
        [Route("PostBankDetails")]
        public IActionResult PostBankDetails([FromBody] BOBankMaster bankMaster)
        {
            BOBankMaster saved = BankMasterObj.PostBankDetails(bankMaster);
            return StatusCode(saved.StatusCode, saved);
        }

        // PUT api/<BankMasterController>/5
        [HttpPut]
        [Route("UpdateDetails")]
        public IActionResult UpdateBankDetails([FromQuery] int id, [FromBody] BOBankMaster bankMaster)
        {
            // return (BankMasterObj.UpdateBankDetails(bankMaster, id)) ? Ok("Updated successfully") : StatusCode(500);
            BOBankMaster result = BankMasterObj.UpdateBankDetails(bankMaster, id);
            return StatusCode(result.StatusCode, result.Message);
        }

        // DELETE api/<BankMasterController>/5
        [HttpDelete]
        [Route("DeleteBankDetail")]
        public IActionResult DeleteBankDetail([FromQuery] int id, BOBankMaster bankMaster)
        {
            // return (BankMasterObj.DeleteBankDetail(id, bankMaster)) ? Ok("Deleted successfully") : StatusCode(500);
            BOBankMaster result = BankMasterObj.DeleteBankDetail(id, bankMaster);
            return StatusCode(result.StatusCode, result.Message);
        }
    }
}
