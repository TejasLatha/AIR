﻿using Anual_Information_Return.BusinessLayer;
using Anual_Information_Return.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Anual_Information_Return.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        BLCustomer CustomerObj = new BLCustomer();
        // GET: api/<CustomerController>
        [HttpGet]
        [Route("GetAllCustomerDetails")]
        public IActionResult GetAllCustomerDetails()
        {
            List<BOCustomer> lstOfCustomers = new List<BOCustomer>();
            lstOfCustomers = CustomerObj.GetAllCustomerDetails();
            return lstOfCustomers?.Any() != true ? Ok("The customer table is empty"):Ok(lstOfCustomers);
        }

        // GET api/<CustomerController>/5
        [HttpGet]
        [Route("GetOneCustomerDetail")]
        public IActionResult GetOneCustomerDetail([FromQuery] int id)
        {
            BOCustomer obj = CustomerObj.GetOnlyOneCustomerDetail(id);
            return  obj==null?Ok("Invalid Customer ID"):Ok(obj);

        }

        // POST api/<CustomerController>
        [HttpPost]
        [Route("PostCustomerDetails")]
        public IActionResult PostCustomerDetails([FromBody] BOCustomer customer)
        {
            BOCustomer saved = CustomerObj.PostCustomerDetails(customer);
            return StatusCode(saved.StatusCode, saved);
        }

        // PUT api/<CustomerController>/5
        [HttpPut]
        public IActionResult UpdateCustomerDetails([FromQuery] int id, [FromBody] BOCustomer customer)
        {
           // return (CustomerObj.BLUpdateCustomerDetails(customer, id)) == true ? Ok("Updated successfully") : StatusCode(500);


            BOCustomer result = CustomerObj.BLUpdateCustomerDetails(customer, id);
            return StatusCode(result.StatusCode, result.Message);
        }

        // DELETE api/<CustomerController>/5
        [HttpDelete]
        [Route("DeleteCustomerDetail")]
        public IActionResult Delete([FromQuery] int id , BOCustomer customer)
        {
            //  return (CustomerObj.DeleteCustomerDetail(id)) == true ? Ok("Updated successfully") : StatusCode(500);


            BOCustomer result = CustomerObj.DeleteCustomerDetail(id, customer);
            return StatusCode(result.StatusCode, result.Message);


        }

    }
}




