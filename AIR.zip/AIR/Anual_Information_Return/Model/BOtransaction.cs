﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class BOtransaction : Response
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public int CustomerId { get; set; }

        [Required]
        public int BranchId { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public DateTime DateOfTransaction { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(30)]
        public string? DoneBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }


    }
}
