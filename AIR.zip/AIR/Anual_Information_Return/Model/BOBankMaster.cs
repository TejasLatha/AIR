﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class BOBankMaster : Response
    {
      
            public int BankId { get; set; }

            [Required]
            public string BankName { get; set; }
            public Address address { get; set; }    
       

    }
}
