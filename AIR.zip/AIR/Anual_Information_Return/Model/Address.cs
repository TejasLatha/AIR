﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class Address
    {
        
            [Required(AllowEmptyStrings = false)]
            public string? Area { get; set; }
            public string? Street { get; set; }
            [Required]
            public string? Pincode { get; set; }
            public int TalukID { get; set; }
            public int DistrictID { get; set; }

        
    }
}
