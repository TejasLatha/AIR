﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class Response
    {
        public bool IsSucces {  get; set; } =true;
        public string? Message { get; set; } 
        public int StatusCode { get; set; } 
    }
}
