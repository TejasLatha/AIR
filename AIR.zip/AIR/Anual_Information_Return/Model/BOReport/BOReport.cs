﻿namespace Anual_Information_Return.Model.BOReport
{
    public class BOReport : Address
    {
        public class BranchReport
        {
            public string? Branchname { get; set; }
            public string? BranchCode { get; set; }
            public string? IfscCode { get; set; }
            public string? Area {  get; set; }

            public string? Pincode { get; set; }

            public string? Street {  get; set; } 
          
        }
    }
}
