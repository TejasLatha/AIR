﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class BOCustomer : Response
    {
        public int ID { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(30)]
        public string? FirstName { get; set; }

        [StringLength(30)]
        public string? MiddleName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(30)]
        public string? LastName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(30)]
        public string? FatherName { get; set; }
        public string? MotherName { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        public Address TempAdress { get; set; }

        public Address PeramanentAdress { get; set; }

        [Required(AllowEmptyStrings = false)]

        public int Gender { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(12)]
        public string? MobileNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string? AadharNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string? PanNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string? EmailID { get; set; }

    }
}
