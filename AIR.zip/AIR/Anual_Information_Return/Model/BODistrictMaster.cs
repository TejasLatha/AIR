﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class BODistrictMaster : Response
    {
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(50)]
        public string? DistrictName { get; set; }
    }
}
