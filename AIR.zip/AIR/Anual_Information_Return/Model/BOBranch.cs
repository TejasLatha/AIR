﻿namespace Anual_Information_Return.Model
{
    public class BOBranch : Response
    {
        public  int BranchId { get; set; }
        public string BranchName { get; set; }
        public String Code { get; set; }
        public string IfscCode { get; set; }
        public Address Address { get; set; } 
        public int BankId {  get; set; }    


    }
}
