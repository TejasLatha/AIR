﻿using System.ComponentModel.DataAnnotations;

namespace Anual_Information_Return.Model
{
    public class BOTalukMaster : Response
    {
       
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string Name { get; set; }

        [Required]
        public int DistricID { get; set; }
    }
}
